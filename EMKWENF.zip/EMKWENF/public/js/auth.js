const API = '';

function showAlert(msg, type = 'danger') {
  const el = document.getElementById('alert');
  if (!el) return;
  el.className = `alert alert-${type}`;
  el.textContent = msg;
  el.classList.remove('d-none');
}

// If already logged in, redirect straight to the correct role dashboard
(function redirectIfLoggedIn() {
  try {
    const token = localStorage.getItem('token');
    const user = JSON.parse(localStorage.getItem('user') || 'null');
    if (token && user && user.role) {
      const role = user.role;
      if (role === 'admin') window.location.href = '/admin/dashboard.html';
      else if (role === 'finance') window.location.href = '/finance/dashboard.html';
      else if (role === 'instructor') window.location.href = '/instructor/dashboard.html';
      else if (role === 'student') window.location.href = '/student/dashboard.html';
    }
  } catch (e) { /* ignore */ }
})();

document.getElementById('loginForm')?.addEventListener('submit', async (e) => {
  e.preventDefault();
  const btn = document.getElementById('loginBtn');
  btn.disabled = true;
  btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Logging in...';

  const username = document.getElementById('username').value.trim();
  const password = document.getElementById('password').value;

  try {
    const res = await fetch(`${API}/api/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Login failed');

    localStorage.setItem('token', data.token);
    localStorage.setItem('user', JSON.stringify(data.user));

    // Redirect each user to their respective dashboard based on their role
    const role = data.user.role;
    if (role === 'admin') {
      window.location.href = '/admin/dashboard.html';
    } else if (role === 'finance') {
      window.location.href = '/finance/dashboard.html';
    } else if (role === 'instructor') {
      window.location.href = '/instructor/dashboard.html';
    } else if (role === 'student') {
      window.location.href = '/student/dashboard.html';
    } else {
      window.location.href = '/';
    }
  } catch (err) {
    showAlert(err.message);
    btn.disabled = false;
    btn.innerHTML = '<i class="fas fa-sign-in-alt me-2"></i> Login';
  }
});

function requireAuth(allowedRoles = []) {
  const token = localStorage.getItem('token');
  const user = JSON.parse(localStorage.getItem('user') || 'null');
  if (!token || !user) {
    window.location.href = '/';
    return null;
  }
  if (allowedRoles.length && !allowedRoles.includes(user.role)) {
    // Send user to their own dashboard instead of login page
    if (user.role === 'admin') window.location.href = '/admin/dashboard.html';
    else if (user.role === 'finance') window.location.href = '/finance/dashboard.html';
    else if (user.role === 'instructor') window.location.href = '/instructor/dashboard.html';
    else if (user.role === 'student') window.location.href = '/student/dashboard.html';
    else window.location.href = '/';
    return null;
  }
  return user;
}

function logout() {
  const token = localStorage.getItem('token');
  fetch(`${API}/api/logout`, {
    method: 'POST',
    headers: { 'x-auth-token': token }
  }).finally(() => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    window.location.href = '/';
  });
}

async function api(path, options = {}) {
  const token = localStorage.getItem('token');
  const headers = {
    'Content-Type': 'application/json',
    'x-auth-token': token,
    ...(options.headers || {})
  };
  const res = await fetch(`${API}${path}`, { ...options, headers });
  if (res.status === 401) {
    logout();
    throw new Error('Session expired');
  }
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}

function formatMoney(n) {
  return 'KES ' + Number(n).toLocaleString('en-KE');
}

function formatDate(d) {
  if (!d) return '-';
  return new Date(d).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
}
