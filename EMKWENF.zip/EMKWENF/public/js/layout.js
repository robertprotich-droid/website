function renderSidebar(user, activePage) {
  const role = user.role;
  let links = '';

  if (role === 'admin') {
    links = `
      <div class="nav-section">Main</div>
      <a href="/admin/dashboard.html" class="nav-link ${activePage==='dashboard'?'active':''}"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
      <a href="/admin/students.html" class="nav-link ${activePage==='students'?'active':''}"><i class="fas fa-user-graduate"></i> Students</a>
      <a href="/admin/instructors.html" class="nav-link ${activePage==='instructors'?'active':''}"><i class="fas fa-chalkboard-teacher"></i> Instructors</a>
      <a href="/admin/courses.html" class="nav-link ${activePage==='courses'?'active':''}"><i class="fas fa-book"></i> Courses</a>
      <a href="/admin/users.html" class="nav-link ${activePage==='users'?'active':''}"><i class="fas fa-users-cog"></i> Users</a>
      <div class="nav-section">Finance</div>
      <a href="/admin/fees.html" class="nav-link ${activePage==='fees'?'active':''}"><i class="fas fa-money-bill-wave"></i> Fees</a>
      <div class="nav-section">Academic</div>
      <a href="/admin/grades.html" class="nav-link ${activePage==='grades'?'active':''}"><i class="fas fa-chart-line"></i> Grades</a>
      <a href="/admin/notices.html" class="nav-link ${activePage==='notices'?'active':''}"><i class="fas fa-bullhorn"></i> Notices</a>
    `;
  } else if (role === 'finance') {
    links = `
      <div class="nav-section">Main</div>
      <a href="/finance/dashboard.html" class="nav-link ${activePage==='dashboard'?'active':''}"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
      <a href="/finance/fees.html" class="nav-link ${activePage==='fees'?'active':''}"><i class="fas fa-money-bill-wave"></i> Fee Management</a>
      <a href="/finance/students.html" class="nav-link ${activePage==='students'?'active':''}"><i class="fas fa-user-graduate"></i> Students</a>
      <a href="/finance/notices.html" class="nav-link ${activePage==='notices'?'active':''}"><i class="fas fa-bullhorn"></i> Notices</a>
    `;
  } else if (role === 'instructor') {
    links = `
      <div class="nav-section">Main</div>
      <a href="/instructor/dashboard.html" class="nav-link ${activePage==='dashboard'?'active':''}"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
      <a href="/instructor/students.html" class="nav-link ${activePage==='students'?'active':''}"><i class="fas fa-user-graduate"></i> My Students</a>
      <a href="/instructor/attendance.html" class="nav-link ${activePage==='attendance'?'active':''}"><i class="fas fa-clipboard-check"></i> Attendance</a>
      <a href="/instructor/grades.html" class="nav-link ${activePage==='grades'?'active':''}"><i class="fas fa-chart-line"></i> Grades</a>
      <a href="/instructor/courses.html" class="nav-link ${activePage==='courses'?'active':''}"><i class="fas fa-book"></i> My Courses</a>
    `;
  } else if (role === 'student') {
    links = `
      <div class="nav-section">Main</div>
      <a href="/student/dashboard.html" class="nav-link ${activePage==='dashboard'?'active':''}"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
      <a href="/student/fees.html" class="nav-link ${activePage==='fees'?'active':''}"><i class="fas fa-money-bill-wave"></i> My Fees</a>
      <a href="/student/grades.html" class="nav-link ${activePage==='grades'?'active':''}"><i class="fas fa-chart-line"></i> My Grades</a>
      <a href="/student/attendance.html" class="nav-link ${activePage==='attendance'?'active':''}"><i class="fas fa-clipboard-check"></i> Attendance</a>
      <a href="/student/profile.html" class="nav-link ${activePage==='profile'?'active':''}"><i class="fas fa-user"></i> Profile</a>
    `;
  }

  return `
    <div class="sidebar" id="sidebar">
      <div class="sidebar-brand">
        <img src="/images/logo.jpg" alt="Logo">
        <div>
          <h5>Emkwen Poly</h5>
          <small>Management System</small>
        </div>
      </div>
      <nav class="sidebar-nav">
        ${links}
        <div class="nav-section">Account</div>
        <a href="#" class="nav-link" onclick="logout(); return false;"><i class="fas fa-sign-out-alt"></i> Logout</a>
      </nav>
    </div>
  `;
}

function renderTopbar(user, title) {
  const initials = (user.name || 'U').split(' ').map(n => n[0]).join('').substring(0,2).toUpperCase();
  return `
    <div class="topbar">
      <div class="d-flex align-items-center gap-3">
        <button class="btn btn-sm btn-outline-secondary d-md-none" onclick="document.getElementById('sidebar').classList.toggle('show')">
          <i class="fas fa-bars"></i>
        </button>
        <h5 class="topbar-title mb-0">${title}</h5>
      </div>
      <div class="user-menu">
        <div class="text-end d-none d-sm-block">
          <div class="fw-semibold" style="font-size:0.9rem">${user.name}</div>
          <small class="text-muted text-capitalize">${user.role}</small>
        </div>
        <div class="user-avatar">${initials}</div>
      </div>
    </div>
  `;
}

function initLayout(user, activePage, title) {
  const app = document.getElementById('app');
  if (!app) return;
  app.innerHTML = `
    ${renderSidebar(user, activePage)}
    <div class="main-content">
      ${renderTopbar(user, title)}
      <div class="content-area" id="content"></div>
    </div>
  `;
}
