const express = require('express');
const path = require('path');
const fs = require('fs');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_DIR = path.join(__dirname, 'data');

app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

// Helper to read/write JSON
function readData(file) {
  const filePath = path.join(DATA_DIR, file);
  if (!fs.existsSync(filePath)) return [];
  return JSON.parse(fs.readFileSync(filePath, 'utf8'));
}

function writeData(file, data) {
  fs.writeFileSync(path.join(DATA_DIR, file), JSON.stringify(data, null, 2));
}

// Simple session store (in-memory for demo)
const sessions = {};

function createSession(user) {
  const token = uuidv4();
  sessions[token] = {
    id: user.id,
    username: user.username,
    role: user.role,
    name: user.name,
    email: user.email,
    courseId: user.courseId || null,
    department: user.department || null
  };
  return token;
}

function authMiddleware(req, res, next) {
  const token = req.headers['x-auth-token'] || req.query.token;
  if (!token || !sessions[token]) {
    return res.status(401).json({ error: 'Unauthorized. Please login.' });
  }
  req.user = sessions[token];
  next();
}

function roleMiddleware(...roles) {
  return (req, res, next) => {
    if (!roles.includes(req.user.role)) {
      return res.status(403).json({ error: 'Access denied for your role.' });
    }
    next();
  };
}

// ========== AUTH ==========
app.post('/api/login', async (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ error: 'Username and password required' });
  }
  const users = readData('users.json');
  let user = null;

  // 1. Exact username match (preferred – works for admin, finance, instructors, students)
  user = users.find(u => u.username === username && u.status === 'active');

  // 2. Shared role shortcuts (optional convenience)
  //    - username "instructor" + password trainer2026 → first active instructor
  //    - username "student" + password = any admission number → that student
  if (!user) {
    const lower = username.toLowerCase();
    if (lower === 'instructor') {
      user = users.find(u => u.role === 'instructor' && u.status === 'active');
    } else if (lower === 'student') {
      user = users.find(u => u.role === 'student' && u.status === 'active' &&
        (u.admissionNo === password || u.username === password));
    }
  }

  // 3. Also allow students to log in with admission number as username
  //    (already covered by exact match above since username === admissionNo)

  if (!user) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }

  // Password validation – prefer stored password (plain text in this demo system)
  let valid = false;
  if (user.password === password) {
    valid = true;
  } else {
    // Keep backward-compatible hardcoded checks + bcrypt fallback
    if (user.role === 'admin' && password === 'adminemkwen2026') valid = true;
    else if (user.role === 'finance' && password === 'finance2026fee') valid = true;
    else if (user.role === 'instructor' && password === 'trainer2026') valid = true;
    else if (user.role === 'student' && (password === user.admissionNo || password === user.username)) valid = true;
    else {
      try {
        valid = await bcrypt.compare(password, user.password);
      } catch (e) {
        valid = false;
      }
    }
  }

  if (!valid) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }

  const token = createSession(user);
  res.json({
    token,
    user: {
      id: user.id,
      username: user.username,
      role: user.role,
      name: user.name,
      email: user.email,
      courseId: user.courseId || null,
      department: user.department || null,
      admissionNo: user.admissionNo || null
    }
  });
});

app.post('/api/logout', (req, res) => {
  const token = req.headers['x-auth-token'];
  if (token) delete sessions[token];
  res.json({ message: 'Logged out' });
});

app.get('/api/me', authMiddleware, (req, res) => {
  res.json({ user: req.user });
});

// ========== USERS (Admin) ==========
app.get('/api/users', authMiddleware, roleMiddleware('admin'), (req, res) => {
  const users = readData('users.json').map(u => {
    const { password, ...safe } = u;
    return safe;
  });
  res.json(users);
});

app.post('/api/users', authMiddleware, roleMiddleware('admin'), async (req, res) => {
  const users = readData('users.json');
  const { username, password, role, name, email, phone, department, courseId, admissionNo } = req.body;

  // Limits
  if (role === 'admin' && users.filter(u => u.role === 'admin').length >= 1) {
    return res.status(400).json({ error: 'Only 1 admin allowed' });
  }
  if (role === 'finance' && users.filter(u => u.role === 'finance').length >= 1) {
    return res.status(400).json({ error: 'Only 1 finance officer allowed' });
  }
  if (role === 'instructor' && users.filter(u => u.role === 'instructor').length >= 12) {
    return res.status(400).json({ error: 'Maximum 12 instructors allowed' });
  }
  if (role === 'student' && users.filter(u => u.role === 'student').length >= 300) {
    return res.status(400).json({ error: 'Maximum 300 students allowed' });
  }
  // For students, username & password default to admission number
  let finalUsername = username;
  let finalPassword = password || 'password123';
  let finalAdmissionNo = admissionNo;

  if (role === 'student') {
    finalAdmissionNo = admissionNo || `EP/${new Date().getFullYear()}/${String(users.filter(u => u.role === 'student').length + 1).padStart(3, '0')}`;
    finalUsername = finalAdmissionNo;          // username = admission number
    finalPassword = finalAdmissionNo;          // password = admission number
  }

  if (users.find(u => u.username === finalUsername)) {
    return res.status(400).json({ error: 'Username already exists' });
  }

  // Store plain for the official role passwords / admission numbers (login handles both)
  const newUser = {
    id: `${role.substring(0, 3)}-${uuidv4().substring(0, 8)}`,
    username: finalUsername,
    password: finalPassword,
    role,
    name,
    email,
    phone: phone || '',
    status: 'active',
    createdAt: new Date().toISOString()
  };
  if (role === 'instructor') newUser.department = department || '';
  if (role === 'student') {
    newUser.admissionNo = finalAdmissionNo;
    newUser.courseId = courseId || null;
  }

  users.push(newUser);
  writeData('users.json', users);

  // Also add to students.json if student
  if (role === 'student') {
    const students = readData('students.json');
    students.push({
      id: newUser.id,
      admissionNo: newUser.admissionNo,
      name,
      gender: req.body.gender || '',
      dob: req.body.dob || '',
      phone: phone || '',
      email,
      address: req.body.address || '',
      courseId: courseId || null,
      enrollmentDate: new Date().toISOString().split('T')[0],
      status: 'active',
      guardianName: req.body.guardianName || '',
      guardianPhone: req.body.guardianPhone || ''
    });
    writeData('students.json', students);

    // Create fee record
    const courses = readData('courses.json');
    const course = courses.find(c => c.id === courseId);
    if (course) {
      const fees = readData('fees.json');
      fees.push({
        id: `fee-${uuidv4().substring(0, 8)}`,
        studentId: newUser.id,
        admissionNo: newUser.admissionNo,
        courseId,
        totalFee: course.fee,
        amountPaid: 0,
        balance: course.fee,
        payments: [],
        status: 'unpaid'
      });
      writeData('fees.json', fees);
      course.enrolled = (course.enrolled || 0) + 1;
      writeData('courses.json', courses);
    }
  }

  const { password: _, ...safe } = newUser;
  res.status(201).json(safe);
});

app.put('/api/users/:id', authMiddleware, roleMiddleware('admin'), (req, res) => {
  const users = readData('users.json');
  const idx = users.findIndex(u => u.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'User not found' });
  const updates = req.body;
  delete updates.password; // handle separately
  delete updates.id;
  users[idx] = { ...users[idx], ...updates };
  writeData('users.json', users);
  const { password, ...safe } = users[idx];
  res.json(safe);
});

app.delete('/api/users/:id', authMiddleware, roleMiddleware('admin'), (req, res) => {
  let users = readData('users.json');
  const user = users.find(u => u.id === req.params.id);
  if (!user) return res.status(404).json({ error: 'User not found' });
  if (user.role === 'admin') return res.status(400).json({ error: 'Cannot delete admin' });
  users = users.filter(u => u.id !== req.params.id);
  writeData('users.json', users);
  res.json({ message: 'User deleted' });
});

// ========== COURSES ==========
app.get('/api/courses', authMiddleware, (req, res) => {
  res.json(readData('courses.json'));
});

app.post('/api/courses', authMiddleware, roleMiddleware('admin'), (req, res) => {
  const courses = readData('courses.json');
  const newCourse = {
    id: `course-${uuidv4().substring(0, 8)}`,
    ...req.body,
    enrolled: 0,
    status: 'active'
  };
  courses.push(newCourse);
  writeData('courses.json', courses);
  res.status(201).json(newCourse);
});

app.put('/api/courses/:id', authMiddleware, roleMiddleware('admin'), (req, res) => {
  const courses = readData('courses.json');
  const idx = courses.findIndex(c => c.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Course not found' });
  courses[idx] = { ...courses[idx], ...req.body };
  writeData('courses.json', courses);
  res.json(courses[idx]);
});

// ========== STUDENTS ==========
app.get('/api/students', authMiddleware, (req, res) => {
  const students = readData('students.json');
  if (req.user.role === 'instructor') {
    // Only students in their courses
    const courses = readData('courses.json').filter(c => c.instructorId === req.user.id);
    const courseIds = courses.map(c => c.id);
    return res.json(students.filter(s => courseIds.includes(s.courseId)));
  }
  if (req.user.role === 'student') {
    return res.json(students.filter(s => s.id === req.user.id));
  }
  res.json(students);
});

app.get('/api/students/:id', authMiddleware, (req, res) => {
  const students = readData('students.json');
  const student = students.find(s => s.id === req.params.id);
  if (!student) return res.status(404).json({ error: 'Student not found' });
  if (req.user.role === 'student' && student.id !== req.user.id) {
    return res.status(403).json({ error: 'Access denied' });
  }
  res.json(student);
});

// ========== FEES (Finance + Admin + Student view own) ==========
app.get('/api/fees', authMiddleware, (req, res) => {
  let fees = readData('fees.json');
  if (req.user.role === 'student') {
    fees = fees.filter(f => f.studentId === req.user.id);
  }
  res.json(fees);
});

app.post('/api/fees/payment', authMiddleware, roleMiddleware('finance', 'admin'), (req, res) => {
  const { studentId, amount, method, reference } = req.body;
  const fees = readData('fees.json');
  const fee = fees.find(f => f.studentId === studentId);
  if (!fee) return res.status(404).json({ error: 'Fee record not found' });
  const amt = parseFloat(amount);
  if (isNaN(amt) || amt <= 0) return res.status(400).json({ error: 'Invalid amount' });

  fee.payments.push({
    id: `pay-${uuidv4().substring(0, 8)}`,
    date: new Date().toISOString().split('T')[0],
    amount: amt,
    method: method || 'Cash',
    reference: reference || '',
    receivedBy: req.user.id
  });
  fee.amountPaid += amt;
  fee.balance = Math.max(0, fee.totalFee - fee.amountPaid);
  fee.status = fee.balance === 0 ? 'paid' : (fee.amountPaid > 0 ? 'partial' : 'unpaid');
  writeData('fees.json', fees);
  res.json(fee);
});

// ========== ATTENDANCE ==========
app.get('/api/attendance', authMiddleware, (req, res) => {
  let att = readData('attendance.json');
  if (req.user.role === 'instructor') {
    att = att.filter(a => a.instructorId === req.user.id);
  }
  if (req.user.role === 'student') {
    att = att.map(a => ({
      ...a,
      records: a.records.filter(r => r.studentId === req.user.id)
    })).filter(a => a.records.length > 0);
  }
  res.json(att);
});

app.post('/api/attendance', authMiddleware, roleMiddleware('instructor', 'admin'), (req, res) => {
  const att = readData('attendance.json');
  const newAtt = {
    id: `att-${uuidv4().substring(0, 8)}`,
    courseId: req.body.courseId,
    date: req.body.date || new Date().toISOString().split('T')[0],
    instructorId: req.user.id,
    records: req.body.records || []
  };
  att.push(newAtt);
  writeData('attendance.json', att);
  res.status(201).json(newAtt);
});

// ========== GRADES ==========
app.get('/api/grades', authMiddleware, (req, res) => {
  let grades = readData('grades.json');
  if (req.user.role === 'instructor') {
    grades = grades.filter(g => g.recordedBy === req.user.id);
  }
  if (req.user.role === 'student') {
    grades = grades.filter(g => g.studentId === req.user.id);
  }
  res.json(grades);
});

app.post('/api/grades', authMiddleware, roleMiddleware('instructor', 'admin'), (req, res) => {
  const grades = readData('grades.json');
  const { studentId, courseId, term, assessments, remarks } = req.body;
  let total = 0, maxTotal = 0;
  (assessments || []).forEach(a => {
    total += a.score || 0;
    maxTotal += a.maxScore || 0;
  });
  const percent = maxTotal > 0 ? (total / maxTotal) * 100 : 0;
  let grade = 'E';
  if (percent >= 80) grade = 'A';
  else if (percent >= 70) grade = 'B+';
  else if (percent >= 60) grade = 'B';
  else if (percent >= 50) grade = 'C';
  else if (percent >= 40) grade = 'D';

  const newGrade = {
    id: `grade-${uuidv4().substring(0, 8)}`,
    studentId,
    courseId,
    term: term || 'Term 1',
    assessments: assessments || [],
    total,
    maxTotal,
    grade,
    remarks: remarks || '',
    recordedBy: req.user.id,
    date: new Date().toISOString().split('T')[0]
  };
  grades.push(newGrade);
  writeData('grades.json', grades);
  res.status(201).json(newGrade);
});

// ========== NOTICES ==========
app.get('/api/notices', authMiddleware, (req, res) => {
  let notices = readData('notices.json');
  const role = req.user.role;
  notices = notices.filter(n => n.audience === 'all' || n.audience === role + 's' || (role === 'admin'));
  res.json(notices);
});

app.post('/api/notices', authMiddleware, roleMiddleware('admin', 'finance'), (req, res) => {
  const notices = readData('notices.json');
  const newNotice = {
    id: `notice-${uuidv4().substring(0, 8)}`,
    title: req.body.title,
    content: req.body.content,
    postedBy: req.user.id,
    date: new Date().toISOString().split('T')[0],
    priority: req.body.priority || 'medium',
    audience: req.body.audience || 'all'
  };
  notices.unshift(newNotice);
  writeData('notices.json', notices);
  res.status(201).json(newNotice);
});

// ========== DASHBOARD STATS ==========
app.get('/api/stats', authMiddleware, (req, res) => {
  const students = readData('students.json');
  const courses = readData('courses.json');
  const fees = readData('fees.json');
  const users = readData('users.json');
  const grades = readData('grades.json');

  const stats = {
    totalStudents: students.length,
    totalCourses: courses.length,
    totalInstructors: users.filter(u => u.role === 'instructor').length,
    totalRevenue: fees.reduce((s, f) => s + f.amountPaid, 0),
    pendingFees: fees.reduce((s, f) => s + f.balance, 0),
    paidStudents: fees.filter(f => f.status === 'paid').length,
    partialStudents: fees.filter(f => f.status === 'partial').length,
    unpaidStudents: fees.filter(f => f.status === 'unpaid').length
  };

  if (req.user.role === 'instructor') {
    const myCourses = courses.filter(c => c.instructorId === req.user.id);
    stats.myCourses = myCourses.length;
    stats.myStudents = students.filter(s => myCourses.some(c => c.id === s.courseId)).length;
  }
  if (req.user.role === 'student') {
    const myFee = fees.find(f => f.studentId === req.user.id);
    stats.myBalance = myFee ? myFee.balance : 0;
    stats.myPaid = myFee ? myFee.amountPaid : 0;
    stats.myGrades = grades.filter(g => g.studentId === req.user.id);
  }

  res.json(stats);
});

// Fallback to index
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`Emkwen Polytechnic SMS running on http://localhost:${PORT}`);
  console.log('Demo logins (password: password123):');
  console.log('  Admin:      admin');
  console.log('  Finance:    finance');
  console.log('  Instructor: instructor1 / instructor2 / instructor3');
  console.log('  Student:    student1 / student2');
});
