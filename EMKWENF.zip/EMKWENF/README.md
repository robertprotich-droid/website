# Emkwen Polytechnic - School Management System (SMS)

A complete role-based School Management System designed to match the branding and structure of the Emkwen Vocational Centre / Polytechnic website.

## Login Credentials

| Role       | Username          | Password            |
|------------|-------------------|---------------------|
| Admin      | `admin`           | `adminemkwen2026`   |
| Finance    | `finance`         | `finance2026fee`    |
| Instructor | `instructor`      | `trainer2026`       |
| Student    | Admission Number  | Admission Number    |

**Student examples:**
- Username: `EP/2025/001`  → Password: `EP/2025/001`  (Alice Cherono)
- Username: `EP/2025/002`  → Password: `EP/2025/002`  (Brian Rotich)
- You can also type username `student` and the admission number as password.

Each student is directed to their **individual dashboard**.

## User Limits
| Role       | Max Count |
|------------|-----------|
| Admin      | 1         |
| Finance    | 1         |
| Instructor | 12        |
| Student    | 300       |

## How to Run

```bash
cd emkwen-sms
npm install
npm start
```

Open: **http://localhost:3000**

## Features
- Role-based dashboards
- Student admission & management
- Course management (10 vocational courses)
- Fee tracking & payment recording (M-Pesa, Bank, Cash)
- Attendance & Grades
- Notices / announcements
- Real-time statistics

## Branding
- Matches Emkwen Polytechnic website colours (deep blue + gold)
- Logo and institution details included
- Courses match the original site offerings
